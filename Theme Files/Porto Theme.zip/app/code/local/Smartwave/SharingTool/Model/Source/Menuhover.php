<?php
class Smartwave_SharingTool_Model_Source_Menuhover
{

    public function toOptionArray()
    {
        return array(
            array('value' => 0, 'label'=>'Off'),
            array('value' => 1, 'label'=>'On'),            
        );
    }

}