<?php

class Smartwave_Homeslider_Helper_Data extends Mage_Core_Helper_Abstract
{
   
}
